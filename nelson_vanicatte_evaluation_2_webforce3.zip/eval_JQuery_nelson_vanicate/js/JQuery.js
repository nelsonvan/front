// Je verifie si JQuery est bien chargée
$(function(){
    console.log('JQuery est chargé')
 
}) // FIN DU SCOPE